package CO_DIEN;

public class DangDucHieu_2022607420_Hill {
    static final int N = 26; // bảng chữ cái tiếng Anh

    // Tính nghịch đảo modulo
    static int modInverse(int a, int m) {
        a = a % m;
        for (int x = 1; x < m; x++) {
            if ((a * x) % m == 1)
                return x;
        }
        return -1;
    }

    // Mã hóa một khối 2 chữ cái với khóa a, b, c, d
    static int[] encryptBlock(int x1, int x2, int a, int b, int c, int d) {
        int y1 = (a * x1 + b * x2) % N;
        int y2 = (c * x1 + d * x2) % N;
        return new int[]{y1, y2};
    }

    // Giải mã một khối 2 chữ cái với khóa nghịch đảo
    static int[] decryptBlock(int y1, int y2, int a, int b, int c, int d) {
        int det = (a * d - b * c) % N;
        if (det < 0) det += N;

        int detInv = modInverse(det, N);
        if (detInv == -1) throw new RuntimeException("Không tồn tại khóa nghịch đảo");

        // Ma trận nghịch đảo:
        int a1 =  d * detInv % N;
        int b1 = (-b + N) * detInv % N;
        int c1 = (-c + N) * detInv % N;
        int d1 =  a * detInv % N;

        int x1 = (a1 * y1 + b1 * y2) % N;
        int x2 = (c1 * y1 + d1 * y2) % N;
        return new int[]{x1, x2};
    }

    // Mã hóa toàn bộ chuỗi
    static String encrypt(String plaintext, int a, int b, int c, int d) {
        plaintext = plaintext.toUpperCase().replaceAll("[^A-Z]", "");
        if (plaintext.length() % 2 != 0) plaintext += "X"; // chèn X nếu lẻ

        StringBuilder cipher = new StringBuilder();
        for (int i = 0; i < plaintext.length(); i += 2) {
            int x1 = plaintext.charAt(i) - 'A';
            int x2 = plaintext.charAt(i + 1) - 'A';
            int[] encrypted = encryptBlock(x1, x2, a, b, c, d);
            cipher.append((char)(encrypted[0] + 'A'));
            cipher.append((char)(encrypted[1] + 'A'));
        }
        return cipher.toString();
    }

    // Giải mã toàn bộ chuỗi
    static String decrypt(String ciphertext, int a, int b, int c, int d) {
        StringBuilder plain = new StringBuilder();
        for (int i = 0; i < ciphertext.length(); i += 2) {
            int y1 = ciphertext.charAt(i) - 'A';
            int y2 = ciphertext.charAt(i + 1) - 'A';
            int[] decrypted = decryptBlock(y1, y2, a, b, c, d);
            plain.append((char)(decrypted[0] + 'A'));
            plain.append((char)(decrypted[1] + 'A'));
        }
        return plain.toString();
    }

    public static void main(String[] args) {
        // Khóa ví dụ trong hình: | 3 3 |
        //                        | 2 5 |
    	int a = 3;
    	int b = 2;
    	int c = 3;
    	int d = 5;

        String p = "HELP";

        System.out.println("Van ban goc : " + p);
        String maHoa = encrypt(p, a, b, c, d);
        System.out.println("Ma hoa      : " + maHoa);
        String giaiMa = decrypt(maHoa, a, b, c, d);
        System.out.println("Giai ma     : " + giaiMa);
    }
}
