#include <iostream>
using namespace std;

int tinhmod(int a, int b, int n) {
    int np[100];
    int i = 0;

    // Chuy?n b th�nh d�y nh? ph�n
    while (b != 0) {
        np[i] = b % 2;
        b = b / 2;
        i++;
    }

    // T�nh a^b % n
    int f = 1;
    for (int j = i - 1; j >= 0; j--) {  // Ch?nh l?i ch? s? j b?t d?u t? i - 1
        f = (f * f) % n;
        if (np[j] == 1) {
            f = (f * a) % n;
        }
    }

    return f;
}

int main() {
    int a, b, n;
    cout << "Nh?p a, b, n: ";
    cin >> a >> b >> n;

    int result = tinhmod(a, b, n);
    cout << "K?t qu? c?a a^b % n l�: " << result << endl;

    return 0;
}

