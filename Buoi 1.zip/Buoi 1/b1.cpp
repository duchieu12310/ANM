#include <iostream>
using namespace std;

// H�m thu?t to�n Euclid m? r?ng theo gi?i thu?t trong ?nh
int extendedEuclid(int a, int b, int &x, int &y) {
    if (b == 0) { // Bu?c (1)
        x = 1;
        y = 0;
        return a;
    }

    int x2 = 1, x1 = 0, y2 = 0, y1 = 1; // Bu?c (2)

    while (b > 0) { // Bu?c (3)
        int q = a / b;
        int r = a % b;
        int x = x2 - q * x1;
        int y = y2 - q * y1;

        // C?p nh?t gi� tr?
        a = b;
        b = r;
        x2 = x1;
        x1 = x;
        y2 = y1;
        y1 = y;
    }

    // Bu?c (4)
    x = x2;
    y = y2;
    return a; // Tr? v? UCLN(a, b)
}

int main() {
    int a, b, x, y;
    cout << "Nh?p hai s? nguy�n kh�ng �m a v� b (a = b): ";
    cin >> a >> b;

    int gcd = extendedEuclid(a, b, x, y);

    cout << "U?c s? chung l?n nh?t: " << gcd << endl;
    cout << "H? s? x = " << x << ", y = " << y << endl;

    return 0;
}

