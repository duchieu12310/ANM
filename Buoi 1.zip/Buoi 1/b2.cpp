#include <iostream>
using namespace std;

int timd(int e, int n) {
    int r[100], q[100], x[100], y[100];

    int i = 1;
    r[0] = n;
    x[0] = 0;
    y[1] = 1;

    r[1] = e;
    x[1] = 1;
    y[0] = 0;

    while (r[i] != 0) {
        q[i] = r[i - 1] / r[i];
        r[i + 1] = r[i - 1] % r[i];
        x[i + 1] = x[i - 1] - q[i] * x[i];
        y[i + 1] = y[i - 1] - q[i] * y[i];
        i++;
    }

    if (x[i - 1] < 0)
        x[i - 1] += n;

    return x[i - 1];
}

int main() {
    int e, n;
    cout << "Nh?p e v� n: ";
    cin >> e >> n;

    int d = timd(e, n);
    cout << "Gi� tr? d t�m du?c: " << d << endl;

    return 0;
}

