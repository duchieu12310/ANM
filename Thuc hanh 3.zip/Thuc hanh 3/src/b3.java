public class b3 {
    public static void main(String[] args) {
        double[] mang = {4.5, 3.2, 9.8, 1.1, 7.6, 0.9, 5.3, 2.7, 6.1, 8.4, 10.0, 3.6, 2.0, 4.4, 7.7};

        System.out.println("Danh sách số thực:");
        inMang(mang);

        double max = timMax(mang, 0, mang.length - 1);
        System.out.println("\nGiá trị lớn nhất trong danh sách là: " + max);
    }

    // Thuật toán chia để trị tìm giá trị lớn nhất
    public static double timMax(double[] arr, int left, int right) {
        if (left == right) {
            return arr[left]; // chỉ còn 1 phần tử
        }

        int mid = (left + right) / 2;

        double maxTrai = timMax(arr, left, mid);
        double maxPhai = timMax(arr, mid + 1, right);

        return Math.max(maxTrai, maxPhai);
    }

    // Hàm in mảng
    public static void inMang(double[] arr) {
        for (double x : arr) {
            System.out.print(x + " ");
        }
        System.out.println();
    }
}
