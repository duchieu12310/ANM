import java.util.*;

class HocSinh implements Comparable<HocSinh> {
    String hoDem;
    String ten;
    int namSinh;
    String diaChi;

    public HocSinh(String hoDem, String ten, int namSinh, String diaChi) {
        this.hoDem = hoDem;
        this.ten = ten;
        this.namSinh = namSinh;
        this.diaChi = diaChi;
    }

    public String toString() {
        return hoDem + " " + ten + " - Năm sinh: " + namSinh + " - Địa chỉ: " + diaChi;
    }

    @Override
    public int compareTo(HocSinh o) {
        return this.ten.compareToIgnoreCase(o.ten);
    }
}

public class b1 {
	 public static int timKiemTen(List<HocSinh> ds, String ten) {
	        int left = 0;
	        int right = ds.size() - 1;

	        while (left <= right) {
	            int mid = (left + right) / 2;
	            int soSanh = ds.get(mid).ten.compareToIgnoreCase(ten);
	            if (soSanh == 0) {
	                // Lùi lại để tìm vị trí đầu tiên nếu trùng tên
	                while (mid > 0 && ds.get(mid - 1).ten.equalsIgnoreCase(ten)) {
	                    mid--;
	                }
	                return mid;
	            } else if (soSanh < 0) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }

	        return -1;
	    }
    public static void main(String[] args) {
        List<HocSinh> danhSach = new ArrayList<>();
        danhSach.add(new HocSinh("Dang Duc", "Hieu", 2003, "Ha Noi"));
        danhSach.add(new HocSinh("Tran Thi", "Binh", 2002, "Hai Phong"));
        danhSach.add(new HocSinh("Le Van", "Cuong", 2004, "Da Nang"));
        danhSach.add(new HocSinh("Pham Thi", "Dung", 2003, "Hue"));
        danhSach.add(new HocSinh("Hoang Van", "An", 2001, "Quang Ninh"));
        danhSach.add(new HocSinh("Do Thi", "Em", 2005, "Thanh Hoa"));

        // Sắp xếp theo tên (O(nlogn))
        Collections.sort(danhSach);

        System.out.println("Danh sách sau khi sắp xếp theo tên:");
        for (HocSinh hs : danhSach) {
            System.out.println(hs);
        }

        // Nhập tên học sinh cần tìm
        Scanner sc = new Scanner(System.in);
        System.out.print("\nNhập tên học sinh cần tìm: ");
        String tenCanTim = sc.nextLine();

        // Tìm kiếm nhị phân
        int viTri = timKiemTen(danhSach, tenCanTim);

        if (viTri != -1) {
            System.out.println("Tìm thấy học sinh tại vị trí " + viTri + ":");
            System.out.println(danhSach.get(viTri));
        } else {
            System.out.println("Không tìm thấy học sinh có tên '" + tenCanTim + "'.");
        }

        sc.close();
    }

   
}
