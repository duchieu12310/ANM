public class b6 {
	// Hàm chia để trị tìm số chẵn nhỏ nhất
    public static int timSoChanNhoNhat(int[] arr, int left, int right) {
        if (left == right) {
            return (arr[left] % 2 == 0) ? arr[left] : Integer.MAX_VALUE;
        }

        int mid = (left + right) / 2;
        int minTrai = timSoChanNhoNhat(arr, left, mid);
        int minPhai = timSoChanNhoNhat(arr, mid + 1, right);

        return Math.min(minTrai, minPhai);
    }
    public static void main(String[] args) {
        int[] a = {13, 24, 35, 42, 51, 60, 73, 80, 19, 38,
                   27, 46, 59, 62, 75, 86, 91, 22, 17, 14};

        System.out.println("Danh sách số nguyên:");
        for (int x : a) System.out.print(x + " ");

        int ketQua = timSoChanNhoNhat(a, 0, a.length - 1);

        if (ketQua == Integer.MAX_VALUE) {
            System.out.println("\n\nKhông có số chẵn trong danh sách.");
        } else {
            System.out.println("\n\nSố chẵn nhỏ nhất trong danh sách là: " + ketQua);
        }
    }

    
}
