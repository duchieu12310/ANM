public class b5 {
	 // Hàm chia để trị tính tổng số dương
    public static double tinhTongSoDuong(double[] arr, int left, int right) {
        if (left == right) {
            return arr[left] > 0 ? arr[left] : 0;
        }

        int mid = (left + right) / 2;
        double tongTrai = tinhTongSoDuong(arr, left, mid);
        double tongPhai = tinhTongSoDuong(arr, mid + 1, right);

        return tongTrai + tongPhai;
    }
    public static void main(String[] args) {
        double[] a = {1.5, -3.2, 4.8, 0.0, 6.7, -1.1, 2.2, 8.9, -4.4, 5.0,
                      7.7, -6.6, 3.3, 1.1, -2.2, 9.0, 10.1, -7.8, 2.0, 6.6};

        System.out.println("Danh sách số thực:");
        for (double x : a) System.out.print(x + " ");

        double tong = tinhTongSoDuong(a, 0, a.length - 1);
        System.out.println("\n\nTổng các số dương trong danh sách là: " + tong);
    }

   
}
