
import java.util.Scanner;

public class b4 {
    // Thuật toán chia để trị để tính a^n
    public static double luyThua(double a, int n) {
        if (n == 0) return 1;

        double half = luyThua(a, n / 2);

        if (n % 2 == 0)
            return half * half;
        else
            return a * half * half;
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Nhập số thực a: ");
        double a = scanner.nextDouble();

        System.out.print("Nhập số nguyên dương n: ");
        int n = scanner.nextInt();

        if (n < 0) {
            System.out.println("n phải là số nguyên dương!");
        } else {
            double ketQua = luyThua(a, n);
            System.out.println(a + " ^ " + n + " = " + ketQua);
        }

        scanner.close();
    }


}
