import java.util.*;

public class b2 {
    public static void main(String[] args) {
        double[] mang = {4.5, 3.2, 9.8, 1.1, 7.6, 0.9, 5.3, 2.7, 6.1, 8.4, 10.0, 3.6, 2.0, 4.4, 7.7};

        System.out.println("Danh sách ban đầu:");
        inMang(mang);

        mergeSort(mang, 0, mang.length - 1);

        System.out.println("\nDanh sách sau khi sắp xếp tăng dần:");
        inMang(mang);
    }

    // Hàm merge sort
    public static void mergeSort(double[] arr, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;

            mergeSort(arr, left, mid);
            mergeSort(arr, mid + 1, right);

            merge(arr, left, mid, right);
        }
    }

    // Hàm trộn 2 mảng con
    public static void merge(double[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        double[] L = new double[n1];
        double[] R = new double[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[left + i];
        for (int j = 0; j < n2; j++)
            R[j] = arr[mid + 1 + j];

        int i = 0, j = 0;
        int k = left;

        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k++] = L[i++];
            } else {
                arr[k++] = R[j++];
            }
        }

        while (i < n1)
            arr[k++] = L[i++];
        while (j < n2)
            arr[k++] = R[j++];
    }

    // Hàm in mảng
    public static void inMang(double[] arr) {
        for (double x : arr) {
            System.out.print(x + " ");
        }
        System.out.println();
    }
}
